// 基础store模块
import user from './user';

export default {
  user
};
